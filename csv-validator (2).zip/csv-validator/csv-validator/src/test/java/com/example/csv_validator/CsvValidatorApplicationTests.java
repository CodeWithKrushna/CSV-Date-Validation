package com.example.csv_validator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsvValidatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
