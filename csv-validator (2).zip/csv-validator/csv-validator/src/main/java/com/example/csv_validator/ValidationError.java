package com.example.csv_validator;

public class ValidationError
{
    private int row;
    private String message;
    public ValidationError(int row, String message) {
        this.row = row;
        this.message = message;
    }
    // Getters and setters
    public int getRow() { return row; }
    public void setRow(int row) { this.row = row; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}
