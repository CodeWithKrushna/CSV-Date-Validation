package com.example.csv_validator;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class CsvController
{
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    @PostMapping("/validate-csv")
    public ResponseEntity<ValidationResponse> validateCsv(@RequestParam("file") MultipartFile file) {
        List<ValidationError> errors = new ArrayList<>();
        if (file.isEmpty()) {
            errors.add(new ValidationError(0, "File is empty"));
            return ResponseEntity.badRequest().body(new ValidationResponse("error", errors));
        }
        try (CSVReader csvReader = new CSVReader(new InputStreamReader(file.getInputStream()))) {
            List<String[]> rows = csvReader.readAll();
            if (rows.isEmpty()) {
                errors.add(new ValidationError(0, "CSV file has no rows"));
                return ResponseEntity.badRequest().body(new ValidationResponse("error", errors));
            }


            for (int i = 1; i < rows.size(); i++) {
                String[] row = rows.get(i);
                if (row.length < 2) {
                    errors.add(new ValidationError(i + 1, "Row has missing fields"));
                    continue;
                }

                String name = row[0].trim();
                String dateOfBirth = row[1].trim();
                // Validate Name: not empty
                if (name.isEmpty()) {
                    errors.add(new ValidationError(i + 1, "Name is empty"));
                }

                if (dateOfBirth.isEmpty()) {
                    errors.add(new ValidationError(i + 1, "DateOfBirth is empty"));
                } else {
                    try {
                        LocalDate.parse(dateOfBirth, DATE_FORMATTER);
                    } catch (DateTimeParseException e) {
                        errors.add(new ValidationError(i + 1, "DateOfBirth must be in yyyy-MM-dd format"));
                    }
                }
            }

            String status = errors.isEmpty() ? "success" : "error";
            return ResponseEntity.ok(new ValidationResponse(status, errors));
        } catch (IOException | CsvException e) {
            errors.add(new ValidationError(0, "Error reading CSV file: " + e.getMessage()));
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ValidationResponse("error", errors));
        }
    }

}
